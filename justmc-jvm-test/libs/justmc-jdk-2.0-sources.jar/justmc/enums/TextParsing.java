package justmc.enums;

import justmc.Primitive;
import justmc.Text;

public enum TextParsing {
    PLAIN,
    LEGACY,
    MINIMESSAGE,
    JSON
}
