package justmc.enums;

import justmc.Primitive;

public enum BlockFace {
    NORTH,
    SOUTH,
    WEST,
    EAST,
    UP,
    DOWN
}
