package justmc.enums;

import justmc.Primitive;

public enum LocationCoordinate {
    X,
    Y,
    Z,
    YAW,
    PITCH
}
