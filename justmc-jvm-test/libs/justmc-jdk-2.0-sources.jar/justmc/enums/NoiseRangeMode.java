package justmc.enums;

import justmc.Primitive;

public enum NoiseRangeMode {
    ZERO_TO_ONE,
    FULL_RANGE
}
