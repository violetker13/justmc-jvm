package justmc.enums;

import justmc.Primitive;

public enum VariableScope {
    GAME,
    SAVE,
    LOCAL,
    LINE
}
