package justmc.enums;

import justmc.Primitive;

public enum RayCollisionMode {
    ONLY_BLOCKS,
    BLOCKS_AND_ENTITIES,
    ONLY_ENTITIES
}
