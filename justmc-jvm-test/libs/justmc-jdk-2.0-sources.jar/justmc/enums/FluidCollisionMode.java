package justmc.enums;

import justmc.Primitive;

public enum FluidCollisionMode {
    NEVER,
    SOURCE_ONLY,
    ALWAYS
}
