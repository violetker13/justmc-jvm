package justmc.enums;

import justmc.Primitive;

public enum TextMerging {
    SPACES,
    LINES,
    CONCATENATION
}
